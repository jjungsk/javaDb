package com.ssafy.member.model.dao;

public interface MemberDao {

}
