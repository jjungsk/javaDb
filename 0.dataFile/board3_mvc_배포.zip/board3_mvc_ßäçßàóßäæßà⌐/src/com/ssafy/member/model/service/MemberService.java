package com.ssafy.member.model.service;

public interface MemberService {

}
